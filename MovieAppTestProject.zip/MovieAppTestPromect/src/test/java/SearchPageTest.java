import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import pages.*;

import java.time.Duration;

public class SearchPageTest {
    public WebDriver driver;
    public LoginPage loginPage;
    public HomePage homePage;
    public SearchPage searchPage;
    WebDriverWait wait;

    @BeforeMethod
    public void setUp() {
        System.setProperty("webdriver.chrome.driver", "/home/vinod/Downloads/chromedriver-linux64/chromedriver");
        driver = new ChromeDriver();

        loginPage = new LoginPage(driver);
        homePage = new HomePage(driver);
        searchPage = new SearchPage(driver);

        driver.get("https://qamoviesapp.ccbp.tech");
        loginPage.validDetails();
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.urlToBe("https://qamoviesapp.ccbp.tech/"));


    }

    @Test(priority = 1)
    public void searchButtonClick() {
        searchPage.searchButtonClick();
        Assert.assertEquals(searchPage.resultList(),6);
    }

    @Test(priority = 2)
    public void searchInput2() {
        searchPage.searchButtonClick();
        Assert.assertEquals(searchPage.searchInput2(),1);
    }

    @AfterMethod
    public void close() {
        driver.close();
    }
}
