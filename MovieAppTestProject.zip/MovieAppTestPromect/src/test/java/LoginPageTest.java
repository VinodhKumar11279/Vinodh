import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import pages.LoginPage;


public class LoginPageTest {
    public WebDriver driver;
    public LoginPage loginPage;
    WebDriverWait wait;

    @BeforeMethod
    public void setUp() {
        System.setProperty("webdriver.chrome.driver", "/home/vinod/Downloads/chromedriver-linux64/chromedriver");
        driver = new ChromeDriver();
        loginPage = new LoginPage(driver);

        driver.get("https://qamoviesapp.ccbp.tech");
    }

    @Test(priority = 1)
    public void loginPageUi() {

        Assert.assertTrue(loginPage.websiteLogo());
        Assert.assertEquals(loginPage.headingText(),"Login");
        Assert.assertEquals(loginPage.usernameLabel(),"USERNAME");
        Assert.assertEquals(loginPage.passwordLabel(), "PASSWORD");
        Assert.assertTrue(loginPage.button());
    }

    @Test(priority = 2)
    public void emptyInput() {
        Assert.assertTrue(loginPage.emptyInput());

    }

    @Test(priority = 3)
    public void emptyUsername() {
        Assert.assertTrue(loginPage.emptyUsername());
    }

    @Test(priority = 4)
    public void emptyPassword() {
        Assert.assertTrue(loginPage.emptyPassword());
    }

    @Test(priority = 5)
    public void validDetails() {
        Assert.assertEquals(loginPage.validDetails(), "https://qamoviesapp.ccbp.tech/");
    }

    @AfterMethod
    public void close() {
        driver.close();
    }




}
