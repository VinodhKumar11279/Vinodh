package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.beans.Visibility;
import java.time.Duration;
import java.util.List;

public class HomePage {

    public WebDriver driver;
    WebDriverWait wait;

    By headingText = By.tagName("h1");
    By homePlayButton = By.className("home-movie-play-button");
    By trndingNow = By.xpath("//h1[text() = 'Trending Now']/parent::*//img");
    By originals = By.xpath("//h1[text() = 'Originals']/parent::*//img");
    By contactUs = By.xpath("//p[text() = 'Contact Us']");

    By websiteLogo = By.className("website-logo");
    By navElements = By.tagName("nav");

    By navHomePage = By.xpath("//a[text() = 'Home']");
    By homeActiveNav = By.xpath("//a[@class = 'nav-link active-nav-link' and text() = 'Home']");
    By popularPage = By.xpath("//a[text() = 'Popular']");
    By popularActiveNav = By.xpath("//a[@class = 'nav-link active-nav-link' and text() = 'Popular']");
    By accountPage = By.cssSelector("button[class = 'avatar-button']");

    By homeImage = By.xpath("//div[@class='react-slick-item']/img");
    By movieTitle = By.cssSelector("h1[class = 'movie-title']");
    By movieDuration = By.cssSelector("p[class = 'watch-time']");
    By review=By.xpath("//div[@class='movie-review-container']");
    By playButoonE=By.xpath("//button[@class='play-button']");

    public HomePage(WebDriver driver) {
        this.driver = driver;
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        PageFactory.initElements(driver, this);
    }

    public List<WebElement> headingText() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(headingText));

        List<WebElement> headingList = driver.findElements(headingText);

        return headingList;
    }

    public boolean homePlayButton() {
        return driver.findElement(homePlayButton).isDisplayed();
    }

    public int trendingNow() {
        return driver.findElements(trndingNow).size();
    }

    public int originals() {
        return driver.findElements(originals).size();
    }

    public boolean contactUs() {
        return driver.findElement(contactUs).isDisplayed();
    }

    public boolean websiteLogo() {
        return driver.findElement(websiteLogo).isDisplayed();
    }

    public boolean navElements() {
        return driver.findElement(navElements).isDisplayed();
    }

    public boolean homePage() {
        driver.findElement(navHomePage).click();
        wait.until(ExpectedConditions.visibilityOfElementLocated(homeActiveNav));
        return driver.findElement(homeActiveNav).isDisplayed();
    }

    public WebElement popularPage() {
        driver.findElement(popularPage).click();
        wait.until(ExpectedConditions.visibilityOfElementLocated(popularActiveNav));
        return driver.findElement(popularActiveNav);
    }

    public String accountPage() {
        driver.findElement(accountPage).click();
        wait.until(ExpectedConditions.urlToBe("https://qamoviesapp.ccbp.tech/account"));

        return driver.getCurrentUrl();
    }

    public void homeImage() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(homeImage));
        driver.findElement(homeImage).click();
    }

    public WebElement movieTitle() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(movieTitle));
        return driver.findElement(movieTitle);
    }

    public WebElement movieDuration() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(movieTitle));
        return driver.findElement(movieDuration);
    }

    public WebElement review() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(review));
        return driver.findElement(review);
    }

    public WebElement playButton() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(playButoonE));
        return driver.findElement(playButoonE);
    }



}
