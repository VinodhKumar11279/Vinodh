package pages;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class Accountspage {
    public WebDriver driver;
    WebDriverWait wait;

    By accountHeading = By.cssSelector("h1[class = 'account-heading']");
    By username = By.cssSelector("p[class = 'membership-username']");
    By password = By.cssSelector("p[class = 'membership-password']");
    By planParagraph = By.cssSelector("p[class = 'plan-paragraph']");
    By planDetails = By.cssSelector("p[class = 'plan-details']");
    By logoutButton = By.cssSelector("button[class = 'logout-button']");


    public Accountspage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    public WebElement accountHeading() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(accountHeading));
        return driver.findElement(accountHeading);
    }

    public WebElement username() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(username));
        return driver.findElement(username);
    }

    public WebElement password() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(password));
        return driver.findElement(password);
    }

    public WebElement planparagraph() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(planParagraph));
        return driver.findElement(planParagraph);
    }

    public WebElement planDetails() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(planDetails));
        return driver.findElement(planDetails);
    }

    public WebElement logoutButton() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(logoutButton));
        return driver.findElement(logoutButton);
    }





}
