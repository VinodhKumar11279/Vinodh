package pages;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class LoginPage {

    public WebDriver driver;
    WebDriverWait wait;

    By websitLogo = By.className("login-website-logo");
    By headingText = By.className("sign-in-heading");
    By userNameLabel = By.cssSelector("label[for = 'usernameInput']");
    By passwordLabel = By.cssSelector("label[for = 'passwordInput']");
    By button = By.tagName("button");
    By errorMsg = By.className("error-message");
    By username = By.id("usernameInput");
    By password = By.id("passwordInput");


    public LoginPage(WebDriver driver) {
        this.driver = driver;
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        PageFactory.initElements(driver, this);
    }

    public boolean websiteLogo() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(websitLogo)).isDisplayed();
        return driver.findElement(websitLogo).isDisplayed();
    }

    public String headingText() {
        return driver.findElement(headingText).getText();
    }

    public String usernameLabel() {
        return driver.findElement(userNameLabel).getText();
    }

    public String passwordLabel() {
        return driver.findElement(passwordLabel).getText();
    }

    public boolean button() {
        return driver.findElement(button).isDisplayed();
    }

    public boolean emptyInput() {
        driver.findElement(button).click();
        wait.until(ExpectedConditions.visibilityOfElementLocated(errorMsg));
        return driver.findElement(errorMsg).isDisplayed();
    }

    public boolean emptyUsername() {
        driver.findElement(password).sendKeys("rahul@2021");
        driver.findElement(button).click();
        wait.until(ExpectedConditions.visibilityOfElementLocated(errorMsg));
        return driver.findElement(errorMsg).isDisplayed();
    }

    public boolean emptyPassword() {
        driver.findElement(username).sendKeys("rahul");
        driver.findElement(button).click();
        wait.until(ExpectedConditions.visibilityOfElementLocated(errorMsg));
        return driver.findElement(errorMsg).isDisplayed();
    }

    public String validDetails() {
        driver.findElement(username).sendKeys("rahul");
        driver.findElement(password).sendKeys("rahul@2021");
        driver.findElement(button).click();

        wait.until(ExpectedConditions.urlToBe("https://qamoviesapp.ccbp.tech/"));

        return driver.getCurrentUrl();
    }

}
