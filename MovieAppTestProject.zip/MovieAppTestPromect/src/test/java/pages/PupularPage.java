package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;

public class PupularPage {
    public WebDriver driver;
    WebDriverWait wait;

    By movies = By.cssSelector("li[class = 'movie-icon-item']");
    By movieClick = By.cssSelector("img[alt = 'Venom']");
    By title = By.cssSelector("h1[class = 'movie-title']");
    By time = By.cssSelector("p[class = 'watch-time']");
    By overView = By.cssSelector("p[class = 'movie-overview']");
    By playButton = By.cssSelector("button[class = 'play-button']");



    public PupularPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    public int moviesList() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(movies));
        int n = driver.findElements(movies).size();
        System.out.println(n);
        return n;
    }

    public void movieClick() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(movieClick));
        driver.findElement(movieClick).click();

    }

    public WebElement title() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(title));
        return driver.findElement(title);
    }

    public WebElement time() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(time));
        return driver.findElement(time);
    }

    public WebElement overView() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(overView));
        return driver.findElement(overView);
    }

    public WebElement playButton() {
        wait.until(ExpectedConditions.visibilityOfElementLocated(playButton));
        return driver.findElement(playButton);
    }


}
