package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;

public class SearchPage {
    public WebDriver driver;
    WebDriverWait wait;

    By emptySearchButton = By.cssSelector("button[class = 'search-empty-button']");
    By searchButton = By.cssSelector("button[class='search-button']");
    By searchInput = By.id("search");
    By resultList = By.cssSelector("li[class = 'movie-icon-item']");

    public SearchPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    public void searchButtonClick() {
        driver.findElement(emptySearchButton).click();
        wait.until(ExpectedConditions.urlToBe("https://qamoviesapp.ccbp.tech/search"));
    }

    public int resultList() {
        driver.findElement(searchInput).sendKeys("ti");
        driver.findElement(searchButton).click();

        wait.until(ExpectedConditions.visibilityOfElementLocated(resultList));

        List<WebElement> list = driver.findElements(resultList);

        return list.size();

    }

    public int searchInput2() {
        driver.findElement(searchInput).sendKeys("shang");
        driver.findElement(searchButton).click();

        wait.until(ExpectedConditions.visibilityOfElementLocated(resultList));

        List<WebElement> list = driver.findElements(resultList);

        return list.size();
    }
}
