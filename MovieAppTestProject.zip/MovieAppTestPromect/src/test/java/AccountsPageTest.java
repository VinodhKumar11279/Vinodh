import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import pages.*;

import java.time.Duration;

public class AccountsPageTest {
    public WebDriver driver;
    LoginPage loginPage;
    Accountspage accountspage;
    HomePage homePage;
    WebDriverWait wait;

    @BeforeMethod
    public void setUp() {
        System.setProperty("webdriver.chrome.driver", "/home/vinod/Downloads/chromedriver-linux64/chromedriver");
        driver = new ChromeDriver();
        loginPage = new LoginPage(driver);
        accountspage = new Accountspage(driver);
        homePage = new HomePage(driver);

        driver.get("https://qamoviesapp.ccbp.tech");
        loginPage.validDetails();
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.urlToBe("https://qamoviesapp.ccbp.tech/"));
        homePage.accountPage();

    }

    @Test(priority = 1)
    public void accountPageUi() {
        Assert.assertTrue(accountspage.accountHeading().isDisplayed());
        Assert.assertTrue(accountspage.username().isDisplayed());
        Assert.assertTrue(accountspage.password().isDisplayed());
        Assert.assertTrue(accountspage.planparagraph().isDisplayed());
        Assert.assertTrue(accountspage.planDetails().isDisplayed());
        Assert.assertTrue(accountspage.logoutButton().isDisplayed());
    }

    @AfterMethod
    public void close() {
        driver.close();
    }
}
