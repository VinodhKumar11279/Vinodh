import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import pages.*;

import java.time.Duration;

public class MovieDetailsPageTest {
    public WebDriver driver;
    LoginPage loginPage;
    HomePage homePage;
    PupularPage pupularPage;
    WebDriverWait wait;

    @BeforeMethod
    public void setUp() {
        System.setProperty("webdriver.chrome.driver", "/home/vinod/Downloads/chromedriver-linux64/chromedriver");
        driver = new ChromeDriver();
        loginPage = new LoginPage(driver);
        homePage = new HomePage(driver);
        pupularPage = new PupularPage(driver);

        driver.get("https://qamoviesapp.ccbp.tech");
        loginPage.validDetails();
        wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.urlToBe("https://qamoviesapp.ccbp.tech/"));




    }

    @Test(priority = 1)
    public void homeMovieDeatils() {
        homePage.homeImage();
        Assert.assertTrue(homePage.movieTitle().isDisplayed());
        Assert.assertTrue(homePage.movieDuration().isDisplayed());
        Assert.assertTrue(homePage.review().isDisplayed());
        Assert.assertTrue(homePage.playButton().isDisplayed());

    }

    @Test(priority = 2)
    public void pupularMovieDetails() {

        homePage.popularPage();
        pupularPage.movieClick();
        Assert.assertTrue(pupularPage.title().isDisplayed());
        Assert.assertTrue(pupularPage.time().isDisplayed());
        Assert.assertTrue(pupularPage.overView().isDisplayed());
        Assert.assertTrue(pupularPage.playButton().isDisplayed());
    }

    @AfterMethod
    public void close() {
        driver.close();
    }




}
